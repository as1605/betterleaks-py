package exprruntime

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestAnalysisCapabilities(t *testing.T) {
	got, err := analysisCapabilities(map[string]any{
		"admin": false,
		"write": true,
		"read":  true,
	})
	require.NoError(t, err)
	assert.Equal(t, []string{"read", "write"}, got)
}

func TestAnalysisCapabilitiesRejectsInvalidConditions(t *testing.T) {
	_, err := analysisCapabilities(map[string]any{"root": true})
	require.ErrorContains(t, err, `unknown capability "root"`)

	_, err = analysisCapabilities(map[string]any{"read": "yes"})
	require.ErrorContains(t, err, `"read" must be a boolean`)
}

func TestAnalysisNamespaceContainsAnalysisHelpers(t *testing.T) {
	namespace := analysisNamespace()
	assert.Contains(t, namespace, "capabilities")
	assert.NotContains(t, namespace, "metadata")
	assert.NotContains(t, namespace, "scopes")
}

func TestAnalysisReceivesValidationBinding(t *testing.T) {
	runtime, err := New(nil)
	require.NoError(t, err)
	program, err := runtime.CompileAnalysis(`let scopes = validation.analysis["scopes"] ?? []; {
		"identity": {"id": validation.analysis["owner"]},
		"capabilities": analysis.capabilities({
			"read": validation["status"] == "valid" && matchesAny(scopes, ["^read_"]),
			"write": intersects(scopes, ["write_api"])
		})
	}`)
	require.NoError(t, err)

	result, err := runtime.EvalAnalysisWithComponents(
		t.Context(),
		program,
		map[string]string{"secret": "token", "rule_id": "test"},
		nil,
		nil,
		nil,
		map[string]any{
			"status":   "valid",
			"reason":   "",
			"metadata": map[string]any{},
			"analysis": map[string]any{"owner": "user-1", "scopes": []string{"read_api", "write_api"}},
		},
		EvalOptions{},
	)
	require.NoError(t, err)
	value := result.Value.(map[string]any)
	assert.Equal(t, "user-1", value["identity"].(map[string]any)["id"])
	assert.Equal(t, []string{"read", "write"}, value["capabilities"])
}

func TestAnalysisRejectsInvalidRegexPattern(t *testing.T) {
	runtime, err := New(nil)
	require.NoError(t, err)
	program, err := runtime.CompileAnalysis(`matchesAny(["read_api"], ["*read"])`)
	require.NoError(t, err)

	_, err = runtime.EvalAnalysisWithComponents(
		t.Context(),
		program,
		map[string]string{"secret": "token", "rule_id": "test"},
		nil,
		nil,
		nil,
		nil,
		EvalOptions{},
	)
	require.ErrorContains(t, err, `invalid regex pattern "*read"`)
}
