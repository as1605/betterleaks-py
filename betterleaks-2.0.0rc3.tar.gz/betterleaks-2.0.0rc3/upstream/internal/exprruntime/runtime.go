package exprruntime

import (
	"context"
	"fmt"
	"maps"
	"net/http"
	"os"
	"reflect"
	"sync"
	"time"

	"github.com/expr-lang/expr"
	"github.com/expr-lang/expr/types"
	"github.com/expr-lang/expr/vm"

	"github.com/betterleaks/betterleaks/v2/internal/tokenizer"
	blregexp "github.com/betterleaks/betterleaks/v2/regexp"
)

// Program is the compiled representation used by filter, validation, analysis,
// and explicit revocation expressions.
type Program = *compiledProgram

type compileMode string

const (
	modeFilter     compileMode = "filter"
	modePrefilter  compileMode = "prefilter"
	modeValidation compileMode = "validation"
	modeAnalysis   compileMode = "analysis"
	modeRevocation compileMode = "revocation"
)

type compiledProgram struct {
	vm                   *vm.Program
	mode                 compileMode
	tokenCounter         *tokenizer.Counter
	tokenCounterProvider func() *tokenizer.Counter
	bindings             bindings
	attributeMatch       func(map[string]string) (bool, error)
}

var emptyStringMap = map[string]string{}
var emptyFilterFinding = map[string]any{
	"secret":               "",
	"captures":             emptyStringMap,
	"match":                "",
	"line":                 "",
	"rule_id":              "",
	"description":          "",
	"context":              "",
	"entropy":              "",
	"fragment_raw":         "",
	"match_start_idx":      0,
	"match_end_idx":        0,
	"match_line_start_idx": 0,
	"match_line_end_idx":   0,
}

type EvalOptions struct {
	Debug bool
}

type EvalResult struct {
	Value           any
	Debug           map[string]any
	RequestLimitHit *ValidationRequestLimitHit
}

type evalState struct {
	debug bool
	meta  map[string]any

	limitMu  sync.Mutex
	limitHit *ValidationRequestLimitHit
}

func (s *evalState) addDebug(name string, value any) {
	if s == nil || !s.debug {
		return
	}
	if s.meta == nil {
		s.meta = make(map[string]any)
	}
	s.meta[name] = value
}

func (s *evalState) recordValidationLimitHit(hit ValidationRequestLimitHit) {
	if s == nil {
		return
	}
	s.limitMu.Lock()
	defer s.limitMu.Unlock()
	if s.limitHit == nil {
		s.limitHit = &hit
	}
}

func (s *evalState) validationLimitHit() *ValidationRequestLimitHit {
	if s == nil {
		return nil
	}
	s.limitMu.Lock()
	defer s.limitMu.Unlock()
	if s.limitHit == nil {
		return nil
	}
	hit := *s.limitHit
	return &hit
}

// maxResponseBody is the maximum number of bytes read from an HTTP response body.
const maxResponseBody = 1 << 20 // 1 MB

// Runtime holds compiled Expr programs and the provider services used by
// validation, analysis, and explicit revocation.
type Runtime struct {
	regexEngine blregexp.Engine
	regexCache  sync.Map // pattern list -> *blregexp.Regexp; owned by this engine runtime
	client      *http.Client
	// validationLimiter is applied to every request made through client,
	// including generic HTTP and typed cloud validation bindings.
	validationLimiter *validationRequestLimiter

	mu    sync.RWMutex
	cache map[string]Program

	// These endpoints are used for tests, not for real scans.
	STSEndpoint             string
	GCPTokenEndpoint        string
	AzureTokenEndpoint      string
	AzureStorageEndpoint    string
	AzureAppConfigEndpoint  string
	AzureServiceBusEndpoint string
	AllowedEnv              map[string]struct{}

	tokenCounterProvider func() *tokenizer.Counter
}

type bindings = map[string]any

// DefaultHTTPClient returns an HTTP client with reasonable timeouts.
func DefaultHTTPClient() *http.Client {
	return &http.Client{Timeout: 10 * time.Second}
}

func (e *Runtime) SetHTTPClient(c *http.Client) {
	e.client = wrapValidationLimitClient(c, e.validationLimiter)
}

// SetValidationRequestLimits applies request-level validation limits to the
// Runtime's shared HTTP client.
func (e *Runtime) SetValidationRequestLimits(cfg ValidationRequestLimits) error {
	limiter, err := newValidationRequestLimiter(cfg)
	if err != nil {
		return err
	}
	e.validationLimiter = limiter
	e.client = wrapValidationLimitClient(e.client, limiter)
	return nil
}

func (e *Runtime) SetTokenCounterProvider(provider func() *tokenizer.Counter) {
	e.tokenCounterProvider = provider
}

func New(httpClient *http.Client) (*Runtime, error) {
	return NewWithRegexEngine(httpClient, nil)
}

// NewWithRegexEngine creates a runtime with an independent regex cache.
// A nil engine selects the standard-library engine.
func NewWithRegexEngine(httpClient *http.Client, engine blregexp.Engine) (*Runtime, error) {
	if httpClient == nil {
		httpClient = DefaultHTTPClient()
	}
	return &Runtime{
		client:      httpClient,
		regexEngine: engine,
		cache:       make(map[string]Program),
	}, nil
}

func (e *Runtime) CompileFilter(expression string, counter *tokenizer.Counter) (Program, error) {
	return e.compile(modeFilter, expression, counter)
}

func (e *Runtime) CompilePrefilter(expression string) (Program, error) {
	return e.compile(modePrefilter, expression, nil)
}

func (e *Runtime) CompileValidation(expression string) (Program, error) {
	return e.compile(modeValidation, expression, nil)
}

func (e *Runtime) CompileAnalysis(expression string) (Program, error) {
	return e.compile(modeAnalysis, expression, nil)
}

// CompileRevocation checks an explicit revocation expression without executing it.
func (e *Runtime) CompileRevocation(expression string) (Program, error) {
	return e.compile(modeRevocation, expression, nil)
}

func (e *Runtime) compile(mode compileMode, expression string, counter *tokenizer.Counter) (Program, error) {
	// One Runtime compiles all expression types. The mode is part of the cache key
	// because each expression kind exposes a different binding contract.
	cacheKey := compileCacheKey(mode, expression, counter)
	e.mu.RLock()
	if prg, ok := e.cache[cacheKey]; ok {
		e.mu.RUnlock()
		return prg, nil
	}
	e.mu.RUnlock()

	b, options := e.compileBindings(mode, counter)
	env := compileEnv(b)
	if mode == modeValidation || mode == modeAnalysis || mode == modeRevocation {
		env["finding"] = types.Map{
			"secret": types.String, "rule_id": types.String,
			"captures": types.Map{types.Extra: types.Any},
		}
	}
	vmPrg, err := expr.Compile(expression, append([]expr.Option{expr.Env(env)}, options...)...)
	if err != nil {
		return nil, fmt.Errorf("%s expr compile error: %w", mode, err)
	}
	prg := &compiledProgram{
		vm:                   vmPrg,
		mode:                 mode,
		tokenCounter:         counter,
		tokenCounterProvider: e.tokenCounterProvider,
		bindings:             programBindings(mode, b),
	}
	if mode == modePrefilter {
		prg.attributeMatch = e.compileAttributeMatch(vmPrg.Node())
	}

	e.mu.Lock()
	e.cache[cacheKey] = prg
	e.mu.Unlock()
	return prg, nil
}

func compileCacheKey(mode compileMode, exprText string, counter *tokenizer.Counter) string {
	key := string(mode) + "\x00" + exprText
	if mode == modeFilter {
		key += fmt.Sprintf("\x00%p", counter)
	}
	return key
}

// Function namespaces have a closed set of members and known signatures.
// Keep input maps dynamic: providers and sources supply their keys at runtime.
func compileEnv(b bindings) types.Map {
	env := make(types.Map, len(b))
	for name, value := range b {
		if namespace, ok := value.(map[string]any); ok && len(namespace) > 0 {
			members := make(types.Map, len(namespace))
			for member, function := range namespace {
				functionType := reflect.TypeOf(function)
				if functionType == nil || functionType.Kind() != reflect.Func {
					members = nil
					break
				}
				members[member] = types.TypeOf(function)
			}
			if members != nil {
				env[name] = members
				continue
			}
		}
		env[name] = types.TypeOf(value)
	}
	return env
}

func programBindings(mode compileMode, b bindings) bindings {
	switch mode {
	case modeFilter, modePrefilter:
		return cloneBindings(b)
	default:
		return nil
	}
}

func (e *Runtime) compileBindings(mode compileMode, counter *tokenizer.Counter) (bindings, []expr.Option) {
	switch mode {
	case modeFilter:
		return e.filterBindings(counter, emptyFilterFinding, emptyStringMap), []expr.Option{expr.AsBool()}
	case modePrefilter:
		return e.prefilterBindings(emptyStringMap), []expr.Option{expr.AsBool()}
	case modeValidation:
		b := e.validationBindings(context.Background(), nil, nil, nil, nil, nil)
		setCompileMaps(b)
		return b, []expr.Option{expr.WithContext("ctx")}
	case modeAnalysis:
		b := e.validationBindings(context.Background(), nil, nil, nil, nil, nil)
		setCompileMaps(b)
		b["validation"] = emptyValidationMap()
		b["analysis"] = analysisNamespace()
		return b, []expr.Option{expr.WithContext("ctx")}
	case modeRevocation:
		b := e.revocationBindings(context.Background(), nil, nil, nil, nil)
		setCompileMaps(b)
		return b, []expr.Option{expr.WithContext("ctx")}
	default:
		panic(fmt.Sprintf("unsupported expression mode %q", mode))
	}
}

// Compile and runtime bindings expose the same names. Dynamic values are layered
// onto a shallow copy so compiled programs can share static function bindings.
func (e *Runtime) EvalFilter(prg Program, finding map[string]any, attributes map[string]string) (bool, error) {
	b := prg.evalBindings()
	if finding == nil {
		finding = emptyFilterFinding
	}
	if attributes == nil {
		attributes = make(map[string]string)
	}
	b["finding"] = finding
	b["attributes"] = attributes
	if rt, ok := b["__runtime"].(*runtimeBindings); ok {
		rt.attrs = attributes
		b["setConfidence"] = rt.setConfidence
	}
	return runBool(prg, b, "filter")
}

func (e *Runtime) EvalPrefilter(prg Program, attributes map[string]string) (bool, error) {
	if prg.attributeMatch != nil {
		return prg.attributeMatch(attributes)
	}
	b := prg.evalBindings()
	b["attributes"] = nonNilStringMap(attributes)
	return runBool(prg, b, "prefilter")
}

func (prg Program) evalBindings() bindings {
	if prg.bindings != nil {
		b := cloneBindings(prg.bindings)
		if rt, ok := b["__runtime"].(*runtimeBindings); ok {
			rtCopy := *rt
			rt = &rtCopy
			rt.tokenCounter = prg.tokenCounter
			rt.tokenCounterProvider = prg.tokenCounterProvider
			b["__runtime"] = rt
			b["failsTokenEfficiency"] = rt.failsTokenEfficiency
			b["tokenRatio"] = rt.tokenRatio
		}
		return b
	}
	return bindings{}
}

func cloneBindings(src bindings) bindings {
	dst := make(bindings, len(src))
	maps.Copy(dst, src)
	return dst
}

func runBool(prg Program, b bindings, name string) (bool, error) {
	val, err := expr.Run(prg.vm, b)
	if err != nil {
		return false, err
	}
	result, ok := val.(bool)
	if !ok {
		return false, fmt.Errorf("%s returned non-bool: %T", name, val)
	}
	return result, nil
}

func (e *Runtime) Eval(prg Program, finding, captures map[string]string) (any, error) {
	return e.EvalWithContext(context.Background(), prg, finding, captures, nil)
}

// EvalWithComponents evaluates a validation program with primary named regex
// captures and structured component findings.
func (e *Runtime) EvalWithComponents(prg Program, finding, captures map[string]string, components map[string]any) (any, error) {
	result, err := e.EvalValidationWithComponents(context.Background(), prg, finding, captures, components, nil, EvalOptions{})
	return result.Value, err
}

func (e *Runtime) EvalWithAttributes(prg Program, finding, captures, attributes map[string]string) (any, error) {
	return e.EvalWithContext(context.Background(), prg, finding, captures, attributes)
}

func (e *Runtime) EvalWithContext(ctx context.Context, prg Program, finding, captures, attributes map[string]string) (any, error) {
	result, err := e.EvalValidation(ctx, prg, finding, captures, attributes, EvalOptions{})
	return result.Value, err
}

func (e *Runtime) EvalValidation(ctx context.Context, prg Program, finding, captures, attributes map[string]string, opts EvalOptions) (EvalResult, error) {
	return e.EvalValidationWithComponents(ctx, prg, finding, captures, nil, attributes, opts)
}

// EvalValidationWithComponents evaluates a validation program with structured
// component findings isolated from the primary rule's named capture groups.
func (e *Runtime) EvalValidationWithComponents(ctx context.Context, prg Program, finding, captures map[string]string, components map[string]any, attributes map[string]string, opts EvalOptions) (EvalResult, error) {
	if prg != nil && prg.mode == modeRevocation {
		return EvalResult{}, fmt.Errorf("revocation programs require explicit revocation execution")
	}
	return e.evalProviderProgram(ctx, prg, finding, captures, components, attributes, nil, opts)
}

// EvalAnalysisWithComponents evaluates an analysis program with the successful
// validation result that authorized the analysis stage.
func (e *Runtime) EvalAnalysisWithComponents(ctx context.Context, prg Program, finding, captures map[string]string, components map[string]any, attributes map[string]string, validation map[string]any, opts EvalOptions) (EvalResult, error) {
	if prg != nil && prg.mode == modeRevocation {
		return EvalResult{}, fmt.Errorf("revocation programs require explicit revocation execution")
	}
	if validation == nil {
		validation = emptyValidationMap()
	}
	return e.evalProviderProgram(ctx, prg, finding, captures, components, attributes, validation, opts)
}

// EvalRevocationWithComponents is deliberately separate from scan-time evaluation.
func (e *Runtime) EvalRevocationWithComponents(ctx context.Context, prg Program, finding, captures map[string]string, components map[string]any, opts EvalOptions) (EvalResult, error) {
	if prg == nil || prg.mode != modeRevocation {
		return EvalResult{}, fmt.Errorf("expected a revocation program")
	}
	return e.evalProviderProgram(ctx, prg, finding, captures, components, nil, nil, opts)
}

func (e *Runtime) evalProviderProgram(ctx context.Context, prg Program, finding, captures map[string]string, components map[string]any, attributes map[string]string, validation map[string]any, opts EvalOptions) (EvalResult, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	state := &evalState{debug: opts.Debug}
	ctx = context.WithValue(ctx, validationRequestContextKey{}, &validationRequestContext{
		ruleID: finding["rule_id"],
		state:  state,
	})
	var b bindings
	if prg.mode == modeRevocation {
		b = e.revocationBindings(ctx, finding, captures, components, state)
	} else {
		b = e.validationBindings(ctx, finding, captures, components, attributes, state)
	}
	if validation != nil {
		b["validation"] = validation
		b["analysis"] = analysisNamespace()
	}
	val, err := expr.Run(prg.vm, b)
	return EvalResult{
		Value:           val,
		Debug:           state.meta,
		RequestLimitHit: state.validationLimitHit(),
	}, err
}

func emptyValidationMap() map[string]any {
	return map[string]any{
		"status":   "",
		"reason":   "",
		"metadata": map[string]any{},
		"analysis": map[string]any{},
	}
}

func (e *Runtime) validationBindings(ctx context.Context, finding, captures map[string]string, components map[string]any, attributes map[string]string, state *evalState) bindings {
	if finding == nil {
		finding = emptyStringMap
	}
	if captures == nil {
		captures = emptyStringMap
	}
	componentInputs := make(map[string]any, len(components))
	for id, value := range components {
		component, ok := value.(map[string]any)
		if !ok {
			continue
		}
		captures := component["captures"]
		if strings, ok := captures.(map[string]string); ok {
			captures = captureBindings(strings)
		}
		componentInputs[id] = map[string]any{"secret": component["secret"], "captures": captures}
	}
	components = componentInputs
	findingWithCaptures := map[string]any{
		"secret": finding["secret"], "rule_id": finding["rule_id"], "captures": captureBindings(captures),
	}

	rt := &runtimeBindings{
		validation: e,
		ctx:        ctx,
		finding:    findingWithCaptures,
		components: components,
		debug:      state,
	}
	b := e.baseBindings(rt)
	delete(b, "attributes")
	b["ctx"] = rt.ctx
	b["finding"] = rt.finding
	b["components"] = rt.components
	b["bytes"] = func(s string) []byte { return []byte(s) }
	b["http"] = httpNamespace(rt)
	b["env"] = envNamespace(rt)
	b["strings"] = stringsNamespace()
	b["validate"] = validateNamespace()
	b["crypto"] = cryptoNamespace()
	b["hex"] = hexNamespace()
	b["base64"] = base64Namespace()
	b["time"] = timeNamespace()
	b["aws"] = awsNamespace(rt)
	b["gcp"] = gcpNamespace(rt)
	b["azure"] = azureNamespace(rt)
	return b
}

type runtimeBindings struct {
	validation           *Runtime
	ctx                  context.Context
	tokenCounter         *tokenizer.Counter
	tokenCounterProvider func() *tokenizer.Counter
	finding              any
	attrs                any
	components           any
	debug                *evalState
}

func (e *Runtime) baseBindings(rt *runtimeBindings) bindings {
	if rt.ctx == nil {
		rt.ctx = context.Background()
	}
	if rt.attrs == nil {
		rt.attrs = map[string]any{}
	}

	rtb := bindings{
		"attributes":           rt.attrs,
		"findMatch":            e.findMatch,
		"intersects":           intersects,
		"failsTokenEfficiency": rt.failsTokenEfficiency,
		"tokenRatio":           rt.tokenRatio,
		"matchesAny":           e.matchesAny,
		"containsAny":          containsAny,
		"startsWithAny":        startsWithAny,
		"entropy":              shannonEntropy,
	}
	rtb["__runtime"] = rt
	return rtb
}

func setCompileMaps(b bindings) {
	b["finding"] = map[string]any{"captures": map[string]any{}}
	b["components"] = map[string]any{}
}

func nonNilStringMap(m map[string]string) map[string]string {
	if m == nil {
		return emptyStringMap
	}
	return m
}

func (e *Runtime) filterBindings(counter *tokenizer.Counter, finding map[string]any, attributes map[string]string) bindings {
	rt := &runtimeBindings{tokenCounter: counter, attrs: attributes}
	b := e.baseBindings(rt)
	b["setConfidence"] = rt.setConfidence
	b["finding"] = finding
	b["crypto"] = map[string]any{"sha256": sha256Fingerprint}
	return b
}

func (e *Runtime) prefilterBindings(attributes map[string]string) bindings {
	return bindings{
		"attributes":    attributes,
		"matchesAny":    e.matchesAny,
		"containsAny":   containsAny,
		"startsWithAny": startsWithAny,
	}
}

func (rt *runtimeBindings) envGet(name string) (string, error) {
	e := rt.validation
	if e == nil {
		return "", fmt.Errorf("env: provider environment unavailable")
	}
	if len(e.AllowedEnv) == 0 {
		return "", fmt.Errorf("env: no provider env allowlist configured (use --provider-env-vars)")
	}
	if _, ok := e.AllowedEnv[name]; !ok {
		return "", fmt.Errorf("env: %q not in provider env allowlist", name)
	}
	return os.Getenv(name), nil
}

func (rt *runtimeBindings) envGetOrDefault(name, fallback string) string {
	e := rt.validation
	if e == nil || len(e.AllowedEnv) == 0 {
		return fallback
	}
	if _, ok := e.AllowedEnv[name]; !ok {
		return fallback
	}
	if value, ok := os.LookupEnv(name); ok {
		return value
	}
	return fallback
}

// Capture maps use interface values so missing names are nil in Expr. That
// preserves optional access and null-coalescing semantics for absent captures.
func captureBindings(captures map[string]string) map[string]any {
	values := make(map[string]any, len(captures))
	for name, value := range captures {
		values[name] = value
	}
	return values
}
