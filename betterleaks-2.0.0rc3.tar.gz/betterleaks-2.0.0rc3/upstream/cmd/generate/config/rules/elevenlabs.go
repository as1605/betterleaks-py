package rules

import (
	"github.com/betterleaks/betterleaks/v2/cmd/generate/config/utils"
	"github.com/betterleaks/betterleaks/v2/cmd/generate/secrets"
	"github.com/betterleaks/betterleaks/v2/config"
)

func ElevenLabs() *config.Rule {
	r := config.Rule{
		ID:          "elevenlabs-api-key",
		Confidence:  "high",
		Description: "Detected an ElevenLabs API Key, which may expose AI voice synthesis services to unauthorized access.",
		Regex:       utils.GenerateSemiGenericRegex([]string{"elevenlabs"}, `sk_[0-9a-f]{48}`, true),
		Keywords:    []string{"elevenlabs"},
		FilterExpr:  `entropy(finding["secret"]) <= 3.5`,
	}

	tps := utils.GenerateSampleSecrets("elevenlabs", "sk_"+secrets.NewSecretWithEntropy(utils.Hex("48"), 3.5))
	fps := []string{
		// Too short
		`elevenlabs_key = sk_2a30e5a0d39d5f2c5f6a9d2f95cd0160`,
		// Wrong prefix
		`elevenlabs_key = ak_2a30e5a0d39d5f2c5f6a9d2f95cd016049a6323985479bfd`,
	}
	return utils.Validate(r, tps, fps)
}
