package rules

import (
	"github.com/betterleaks/betterleaks/v2/cmd/generate/config/utils"
	"github.com/betterleaks/betterleaks/v2/cmd/generate/secrets"
	"github.com/betterleaks/betterleaks/v2/config"
)

func SnowflakeAccountHost() *config.Rule {
	// define rule
	r := config.Rule{
		ID:          "snowflake-account-host.1",
		Confidence:  "high",
		Description: "Snowflake account host, used as a component of the programmatic access-token rule.",
		Regex:       `(?i)\b([a-z0-9_-]+(?:\.[a-z0-9_-]+)*\.snowflakecomputing\.com)\b`,
		Keywords:    []string{"snowflakecomputing.com"},
		SkipReport:  true,
	}

	// validate
	tps := []string{
		`SNOWFLAKE_HOST=xy12345.us-east-1.snowflakecomputing.com`,
		`host=acme-prod.eu-west-1.aws.snowflakecomputing.com`,
	}
	fps := []string{
		`SNOWFLAKE_HOST=xy12345.example.com`,
		`SNOWFLAKE_HOST=snowflakecomputing.com.evil.example`,
	}
	return utils.Validate(r, tps, fps)
}

func SnowflakeProgrammaticAccessToken() *config.Rule {
	// define rule
	r := config.Rule{
		ID:          "snowflake-programmatic-access-token.1",
		Confidence:  "high",
		Description: "Snowflake programmatic access token.",
		Regex: utils.GenerateSemiGenericRegex(
			[]string{`(?:snowflake[_. -]*(?:programmatic[_. -]*)?(?:access[_. -]*)?token|sf[_. -]*token)`},
			`[A-Za-z0-9_-]{100,500}`,
			false,
		),
		Keywords: []string{"snowflake", "sf_token"},
		Components: []config.Component{
			{RuleID: "snowflake-account-host.1", Within: "30L"},
		},
		ValidateExpr: `let r = http.post("https://" + (components["snowflake-account-host.1"]?.secret ?? "") + "/api/v2/statements", {
    "Authorization": "Bearer " + finding["secret"],
    "X-Snowflake-Authorization-Token-Type": "PROGRAMMATIC_ACCESS_TOKEN",
    "Content-Type": "application/json",
    "Accept": "application/json"
  }, "{\"statement\":\"select 1\",\"timeout\":5}"); r.status in [200, 202]
    && ((r.body contains "\"statementHandle\"") || (r.body contains "\"resultSetMetaData\"")) ? {
    "result": "valid"
  } : r.status in [401, 403] ? {
    "result": "invalid",
    "reason": "Unauthorized"
  } : validate.unknown(r)`,
		FilterExpr: `entropy(finding["secret"]) < 3.5 || tokenRatio(finding["secret"]) >= 2.5`,
	}

	// validate
	tps := []string{
		"SNOWFLAKE_TOKEN=" + secrets.NewSecretWithEntropy(`[A-Za-z0-9_-]{120}`, 3.5),
	}
	fps := []string{
		`SNOWFLAKE_TOKEN=short`,
		`ACCESS_TOKEN=AbCdEfGhIjKlMnOpQrStUvWxYz1234567890AbCdEfGhIjKlMnOpQrStUvWxYz1234567890AbCdEfGhIjKlMnOpQrStUvWxYz12`,
	}
	return utils.Validate(r, tps, fps)
}
