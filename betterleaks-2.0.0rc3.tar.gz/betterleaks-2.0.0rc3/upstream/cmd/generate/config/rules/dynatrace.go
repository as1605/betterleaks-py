package rules

import (
	"github.com/betterleaks/betterleaks/v2/cmd/generate/config/utils"
	"github.com/betterleaks/betterleaks/v2/cmd/generate/secrets"
	"github.com/betterleaks/betterleaks/v2/config"
)

func Dynatrace() *config.Rule {
	// define rule
	r := config.Rule{
		ID:          "dynatrace-api-token",
		Confidence:  "high",
		Description: "Detected a Dynatrace API token, potentially risking application performance monitoring and data exposure.",
		Regex:       `dt0c01\.(?i)[a-z0-9]{24}\.[a-z0-9]{64}`,
		Keywords:    []string{"dt0c01."},
		FilterExpr:  `entropy(finding["secret"]) <= 4.0`,
	}

	// validate
	tps := utils.GenerateSampleSecrets("dynatrace", "dt0c01."+secrets.NewSecretWithEntropy(utils.AlphaNumeric("24"), 4)+"."+secrets.NewSecretWithEntropy(utils.AlphaNumeric("64"), 4))
	return utils.Validate(r, tps, nil)
}
