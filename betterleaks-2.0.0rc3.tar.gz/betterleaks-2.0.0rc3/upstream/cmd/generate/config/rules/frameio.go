package rules

import (
	"github.com/betterleaks/betterleaks/v2/cmd/generate/config/utils"
	"github.com/betterleaks/betterleaks/v2/cmd/generate/secrets"
	"github.com/betterleaks/betterleaks/v2/config"
)

func FrameIO() *config.Rule {
	// define rule
	r := config.Rule{
		Description: "Found a Frame.io API token, potentially compromising video collaboration and project management.",
		ID:          "frameio-api-token",
		Confidence:  "high",
		Regex:       `fio-u-(?i)[a-z0-9\-_=]{64}`,
		Keywords:    []string{"fio-u-"},
		ValidateExpr: `let r = http.get("https://api.frame.io/v2/me", {
    "Authorization": "Bearer " + finding["secret"],
    "Accept": "application/json"
  }); r.status == 200 ? {
    "result": "valid"
  } : r.status == 401 ? {
    "result": "invalid",
    "reason": "Unauthorized"
  } : validate.unknown(r)`,
		FilterExpr: utils.MinEntropy(3.3),
	}

	// validate
	tps := utils.GenerateSampleSecrets("frameio", "fio-u-"+secrets.NewSecret(utils.AlphaNumericExtended("64")))
	return utils.Validate(r, tps, nil)
}
