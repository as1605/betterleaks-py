package rules

import (
	"github.com/betterleaks/betterleaks/v2/cmd/generate/config/utils"
	"github.com/betterleaks/betterleaks/v2/cmd/generate/secrets"
	"github.com/betterleaks/betterleaks/v2/config"
)

func YandexAWSAccessToken() *config.Rule {
	// define rule
	r := config.Rule{
		ID:          "yandex-aws-access-token",
		Confidence:  "high",
		Description: "Uncovered a Yandex AWS Access Token, potentially compromising cloud resource access and data security on Yandex Cloud.",
		Regex: utils.GenerateSemiGenericRegex([]string{"yandex"},
			`YC[a-zA-Z0-9_\-]{38}`, true),
		Keywords: []string{
			"yandex",
		},
	}

	// validate
	tps := utils.GenerateSampleSecrets("yandex", secrets.NewSecret(`YC[a-zA-Z0-9_\-]{38}`))
	return utils.Validate(r, tps, nil)
}

func YandexAPIKey() *config.Rule {
	// define rule
	r := config.Rule{
		ID:          "yandex-api-key",
		Confidence:  "high",
		Description: "Discovered a Yandex API Key, which could lead to unauthorized access to Yandex services and data manipulation.",
		Regex: utils.GenerateSemiGenericRegex([]string{"yandex"},
			`AQVN[A-Za-z0-9_\-]{35,38}`, true),

		Keywords: []string{
			"yandex",
		},
	}

	// validate
	tps := utils.GenerateSampleSecrets("yandex", secrets.NewSecret(`AQVN[A-Za-z0-9_\-]{35,38}`))
	return utils.Validate(r, tps, nil)
}

func YandexAccessToken() *config.Rule {
	// define rule
	r := config.Rule{
		ID:          "yandex-access-token",
		Confidence:  "high",
		Description: "Found a Yandex Access Token, posing a risk to Yandex service integrations and user data privacy.",
		Regex: utils.GenerateSemiGenericRegex([]string{"yandex"},
			`t1\.[A-Z0-9a-z_-]+[=]{0,2}\.[A-Z0-9a-z_-]{86}[=]{0,2}`, true),

		Keywords: []string{
			"yandex",
		},
	}

	// validate
	tps := utils.GenerateSampleSecrets("yandex", secrets.NewSecret(`t1\.[A-Z0-9a-z_-]+[=]{0,2}\.[A-Z0-9a-z_-]{86}[=]{0,2}`))
	return utils.Validate(r, tps, nil)
}
