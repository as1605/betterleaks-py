package rules

import (
	"github.com/betterleaks/betterleaks/v2/cmd/generate/config/utils"
	"github.com/betterleaks/betterleaks/v2/cmd/generate/secrets"
	"github.com/betterleaks/betterleaks/v2/config"
)

const vercelTokenValidateExpr = `let r = http.get("https://api.vercel.com/v2/user", {
  "Authorization": "Bearer " + finding["secret"]
}); r.status == 200 && (r.json?.user?.id ?? "") != "" ? {
  "result": "valid",
  "analysis": {
    "user_id": r.json?.user?.id ?? "",
    "email": r.json?.user?.email ?? "",
    "username": r.json?.user?.username ?? "",
    "name": r.json?.user?.name ?? ""
  }
} : r.status in [401, 403] ? {
  "result": "invalid",
  "reason": "Unauthorized"
} : validate.unknown(r)`

// User/team scopes identify account boundaries, not effective resource grants.
// One additional GET enriches the cached owner identity without enumerating tokens.
// https://vercel.com/docs/rest-api/authentication/get-auth-token-metadata
const vercelTokenAnalyzeExpr = `let input = validation.analysis;
let r = http.get("https://api.vercel.com/v5/user/tokens/current", {
  "Authorization": "Bearer " + finding["secret"],
  "Accept": "application/json"
});
let details_ok = r.status == 200 && (r.json?.token?.id ?? "") != "";
let token = details_ok ? (r.json?.token ?? {}) : {};
let scopes = token["scopes"] ?? [];
{
  "reason": !details_ok ? "Vercel token metadata could not be retrieved" :
    len(scopes) == 0 ? "Vercel did not return token scope metadata" :
    "Vercel token scopes do not establish resource permissions",
  "identity": {
    "id": input["user_id"] ?? "",
    "email": input["email"] ?? "",
    "username": input["username"] ?? "",
    "name": input["name"] ?? "",
    "account": len(scopes) == 1 && (scopes[0]?.type ?? "") == "team" ? {
      "id": scopes[0]?.teamId ?? ""
    } : {}
  },
  "metadata": {
    "token_id": token["id"] ?? "",
    "token_name": token["name"] ?? "",
    "token_type": token["type"] ?? "",
    "scopes": map(scopes, {{
      "type": #.type ?? "",
      "team_id": #.teamId ?? "",
      "created_at": #.createdAt ?? nil,
      "expires_at": #.expiresAt ?? nil
    }}),
    "created_at": token["createdAt"] ?? nil,
    "expires_at": token["expiresAt"] ?? nil
  },
  "capabilities": []
}`

func VercelAPIToken() *config.Rule {
	r := config.Rule{
		ID:           "vercel-api-token",
		Confidence:   "high",
		Description:  "Detected a Vercel API Token, which may expose deployment and serverless infrastructure to unauthorized access.",
		Regex:        utils.GenerateSemiGenericRegex([]string{"vercel"}, `[A-Z0-9]{24}`, true),
		Keywords:     []string{"vercel"},
		ValidateExpr: vercelTokenValidateExpr,
		AnalyzeExpr:  vercelTokenAnalyzeExpr,
		FilterExpr:   `entropy(finding["secret"]) < 3.5 || tokenRatio(finding["secret"]) >= 2.5`,
	}

	tps := utils.GenerateSampleSecrets("vercel", secrets.NewSecretWithEntropy(`[A-Z0-9]{24}`, 3.5))
	tps = append(tps,
		`vercel-key = DdZV6ZDZW6Vpl7n7JqtrCE5i`,
		`vercel_token = zyMBA1qVEMAf4UNNZtCAbg6u`,
		`vercel_api_key = MTg0AW799OY1HmyDdn84or3C`,
		`vercel_secret = A7n9Xfp3tBz7D0XpOTMWpiOM`,
	)
	fps := []string{
		// Too short
		`vercel_key = DdZV6ZDZW6Vpl7n7Jq`,
		// All same chars (low entropy)
		`vercel_key = AAAAAAAAAAAAAAAAAAAAAAAA`,
	}
	return utils.Validate(r, tps, fps)
}

func VercelPersonalAccessToken() *config.Rule {
	r := config.Rule{
		ID:           "vercel-personal-access-token",
		Confidence:   "high",
		Description:  "Detected a Vercel Personal Access Token (vcp_), which may expose full account and deployment management capabilities.",
		Regex:        utils.GenerateUniqueTokenRegex(`vcp_[A-Za-z0-9_-]{56}`, true),
		Keywords:     []string{"vcp_"},
		ValidateExpr: vercelTokenValidateExpr,
		AnalyzeExpr:  vercelTokenAnalyzeExpr,
		FilterExpr:   `entropy(finding["secret"]) < 3.5 || tokenRatio(finding["secret"]) >= 2.5`,
	}

	tps := utils.GenerateSampleSecrets("vercel", "vcp_"+secrets.NewSecretWithEntropy(`[A-Za-z0-9_-]{56}`, 3.5))
	tps = append(tps,
		`vcp_35UYJwYZDigYATKhxJUAhPqRhit2Xe3dtiG60LsUTHeklEXDQ94Jafpu`,
		`vercel_access_token=vcp_4mcjwVDwqtVCVGWCcxRjdzGpkGZ3NkwXZv8ktcoQ0EG0dnjpMP1Rzi71`,
	)
	fps := []string{
		// Too short
		`vcp_35UYJwYZDigYATKhxJUAhPqRhit2Xe3dtiG60LsUTHe`,
		// Wrong prefix
		`vct_35UYJwYZDigYATKhxJUAhPqRhit2Xe3dtiG60LsUTHeklEXDQ94Jafpu`,
	}
	return utils.Validate(r, tps, fps)
}

func VercelIntegrationToken() *config.Rule {
	r := config.Rule{
		ID:          "vercel-integration-token",
		Confidence:  "high",
		Description: "Detected a Vercel Integration Token (vci_), which may allow third-party service integrations to act on behalf of users.",
		Regex:       utils.GenerateUniqueTokenRegex(`vci_[A-Za-z0-9_-]{56}`, true),
		Keywords:    []string{"vci_"},
		ValidateExpr: `let r = http.get("https://api.vercel.com/v2/user", {
    "Authorization": "Bearer " + finding["secret"]
  }); r.status == 200 && (r.body contains "\"user\"") ? {
    "result": "valid",
    "metadata": {"email": (r.json?.user?.email ?? ""), "username": (r.json?.user?.username ?? ""), "user_id": (r.json?.user?.id ?? "")}
  } : r.status in [401, 403] ? {
    "result": "invalid",
    "reason": "Unauthorized"
  } : validate.unknown(r)`,
		FilterExpr: `entropy(finding["secret"]) < 3.5 || tokenRatio(finding["secret"]) >= 2.5`,
	}

	tps := utils.GenerateSampleSecrets("vercel", "vci_"+secrets.NewSecretWithEntropy(`[A-Za-z0-9_-]{56}`, 3.5))
	tps = append(tps,
		`Vercel Integration Token: vci_35UYJwYZDigYATKhxJUAhPqRhit2Xe3dtiG60LsUTHeklEXDQ94Jafpu`,
	)
	fps := []string{
		// Too short
		`vci_35UYJwYZDigYATKhxJUAhPqRhit2Xe3dtiG60LsUTHe`,
		// Wrong prefix
		`vcp_35UYJwYZDigYATKhxJUAhPqRhit2Xe3dtiG60LsUTHeklEXDQ94Jafpu`,
	}
	return utils.Validate(r, tps, fps)
}

func VercelAppAccessToken() *config.Rule {
	r := config.Rule{
		ID:          "vercel-app-access-token",
		Confidence:  "high",
		Description: "Detected a Vercel App Access Token (vca_), which may allow Sign in with Vercel apps to access user resources.",
		Regex:       utils.GenerateUniqueTokenRegex(`vca_[A-Za-z0-9_-]{56}`, true),
		Keywords:    []string{"vca_"},
		ValidateExpr: `let r = http.post("https://api.vercel.com/login/oauth/userinfo", {
    "Authorization": "Bearer " + finding["secret"]
  }, ""); r.status == 200 && (r.body contains "\"sub\"") ? {
    "result": "valid",
    "metadata": {"email": (r.json?.email ?? ""), "user_id": (r.json?.sub ?? "")}
  } : r.status in [401, 403] ? {
    "result": "invalid",
    "reason": "Unauthorized"
  } : validate.unknown(r)`,
		FilterExpr: `entropy(finding["secret"]) < 3.5 || tokenRatio(finding["secret"]) >= 2.5`,
	}

	tps := utils.GenerateSampleSecrets("vercel", "vca_"+secrets.NewSecretWithEntropy(`[A-Za-z0-9_-]{56}`, 3.5))
	tps = append(tps,
		`vca_BQuu9ChDu3n6Pfh6YQnCshpoYkWDSFKogLqmBtQ0tC8NAA5rXt340sjz`,
	)
	fps := []string{
		// Too short
		`vca_BQuu9ChDu3n6Pfh6YQnCshpoYkWDSFKogLqmBtQ0t`,
		// Wrong prefix
		`vcb_BQuu9ChDu3n6Pfh6YQnCshpoYkWDSFKogLqmBtQ0tC8NAA5rXt340sjz`,
	}
	return utils.Validate(r, tps, fps)
}

func VercelAppRefreshToken() *config.Rule {
	r := config.Rule{
		ID:          "vercel-app-refresh-token",
		Confidence:  "high",
		Description: "Detected a Vercel App Refresh Token (vcr_), which may allow persistent unauthorized access through token refresh flows.",
		Regex:       utils.GenerateUniqueTokenRegex(`vcr_[A-Za-z0-9_-]{56}`, true),
		Keywords:    []string{"vcr_"},
		ValidateExpr: `let r = http.post("https://api.vercel.com/login/oauth/token/introspect", {
    "Content-Type": "application/x-www-form-urlencoded"
  }, "token=" + finding["secret"]); r.status == 200 && (r.body contains "\"active\":true") ? {
    "result": "valid"
  } : r.status == 200 && (r.body contains "\"active\":false") ? {
    "result": "invalid",
    "reason": "Token inactive"
  } : r.status in [401, 403] ? {
    "result": "invalid",
    "reason": "Unauthorized"
  } : validate.unknown(r)`,
		FilterExpr: `entropy(finding["secret"]) < 3.5 || tokenRatio(finding["secret"]) >= 2.5`,
	}

	tps := utils.GenerateSampleSecrets("vercel", "vcr_"+secrets.NewSecretWithEntropy(`[A-Za-z0-9_-]{56}`, 3.5))
	tps = append(tps,
		`vcr_BQuu9ChDu3n6Pfh6YQnCshpoYkWDSFKogLqmBtQ0tC8NAA5rXt340sjz`,
	)
	fps := []string{
		// Too short
		`vcr_BQuu9ChDu3n6Pfh6YQnCshpoYkWDSFKogLqmBtQ0t`,
		// Wrong prefix
		`vcp_BQuu9ChDu3n6Pfh6YQnCshpoYkWDSFKogLqmBtQ0tC8NAA5rXt340sjz`,
	}
	return utils.Validate(r, tps, fps)
}

func VercelAIGatewayKey() *config.Rule {
	r := config.Rule{
		ID:          "vercel-ai-gateway-key",
		Confidence:  "high",
		Description: "Detected a Vercel AI Gateway API Key (vck_), which may expose AI model routing and gateway access to unauthorized parties.",
		Regex:       utils.GenerateUniqueTokenRegex(`vck_[A-Za-z0-9_-]{56}`, true),
		Keywords:    []string{"vck_"},
		ValidateExpr: `let r = http.post("https://ai-gateway.vercel.sh/v1/chat/completions", {
    "Authorization": "Bearer " + finding["secret"],
    "Content-Type": "application/json"
  }, "{\"model\":\"openai/gpt-3.5-turbo\",\"messages\":[{\"role\":\"user\",\"content\":\"x\"}],\"max_tokens\":1}"); r.status in [200, 403] ? {
    "result": "valid"
  } : r.status in [401] ? {
    "result": "invalid",
    "reason": "Unauthorized"
  } : validate.unknown(r)`,
		FilterExpr: `entropy(finding["secret"]) < 3.5 || tokenRatio(finding["secret"]) >= 2.5`,
	}

	tps := utils.GenerateSampleSecrets("vercel", "vck_"+secrets.NewSecretWithEntropy(`[A-Za-z0-9_-]{56}`, 3.5))
	tps = append(tps,
		`vck_2YkmQj1uHqCVNoUx5a9uvRTe81gmAcln5hoRMPWFBU4tulufUf0OzP2K`,
	)
	fps := []string{
		// Too short
		`vck_2YkmQj1uHqCVNoUx5a9uvRTe81gmAcln5hoRMPWFBU4t`,
		// Wrong prefix
		`vcp_2YkmQj1uHqCVNoUx5a9uvRTe81gmAcln5hoRMPWFBU4tulufUf0OzP2K`,
	}
	return utils.Validate(r, tps, fps)
}
