package rules

import (
	"github.com/betterleaks/betterleaks/v2/cmd/generate/config/utils"
	"github.com/betterleaks/betterleaks/v2/config"
)

func Authress() *config.Rule {
	// Rule Definition
	// When changes are made to this rule, regenerate and commit config/betterleaks.toml.
	r := config.Rule{
		ID:          "authress-service-client-access-key",
		Confidence:  "high",
		Description: "Uncovered a possible Authress Service Client Access Key, which may compromise access control services and sensitive data.",
		Regex:       `(?i)\b((?:sc|ext|scauth|authress)_[a-z0-9]{5,30}\.[a-z0-9]{4,6}\.acc[_-][a-z0-9-]{10,32}\.[a-z0-9+/_=-]{30,120})\b`,
		// The `.acc_`/`.acc-` segment is required by the regex and is far
		// rarer in real code than the `sc_`/`ext_` prefixes.
		Keywords: []string{".acc_", ".acc-"},
		ValidateExpr: `let r = http.get("https://api.authress.io/v1/users/me", {
    "Authorization": "Bearer " + finding["secret"]
  }); r.status == 200 && !(r.body contains "\"Unauthorized\"") ? {
    "result": "valid"
  } : r.status in [401, 403] || (r.body contains "\"Unauthorized\"") ? {
    "result": "invalid",
    "reason": "Unauthorized"
  } : validate.unknown(r)`,
		FilterExpr: `entropy(finding["secret"]) < 4.0`,
	}

	// validate
	// https://authress.io/knowledge-base/docs/authorization/service-clients/secrets-scanning/#1-detection
	tps := []string{
		`authress_access_key = "sc_a6DTktFwMEvh87xstYV1BXl.ihwj.acc-0xd1a47h1rr0f.MC4CAQAwBQYDKAVwBCIEIB1wYB62EK24FKxEPHbW0ishcstwp2qs30uLXdWgu4V0"`,
	}
	fps := []string{
		`authress_access_key = "sc_bad.ihwj.acc-0xd1a47h1rr0f.MC4CAQAwBQYDKAVwBCIEIB1wYB62EK24FKxEPHbW0ishcstwp2qs30uLXdWgu4V0"`,
	}
	return utils.Validate(r, tps, fps)
}
