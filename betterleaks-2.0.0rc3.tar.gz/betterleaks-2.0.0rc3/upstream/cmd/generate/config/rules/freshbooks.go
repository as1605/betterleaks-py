package rules

import (
	"github.com/betterleaks/betterleaks/v2/cmd/generate/config/utils"
	"github.com/betterleaks/betterleaks/v2/cmd/generate/secrets"
	"github.com/betterleaks/betterleaks/v2/config"
)

func FreshbooksAccessToken() *config.Rule {
	// define rule
	r := config.Rule{
		ID:          "freshbooks-access-token",
		Confidence:  "high",
		Description: "Discovered a Freshbooks Access Token, posing a risk to accounting software access and sensitive financial data exposure.",
		Regex:       utils.GenerateSemiGenericRegex([]string{"freshbooks"}, utils.AlphaNumeric("64"), true),

		Keywords: []string{
			"freshbooks",
		},
		ValidateExpr: utils.BearerGetValidationExpr("https://api.freshbooks.com/auth/api/v1/users/me", "true"),
		FilterExpr:   `entropy(finding["secret"]) < 3.5 || tokenRatio(finding["secret"]) >= 2.5`,
	}

	// validate
	tps := utils.GenerateSampleSecrets("freshbooks", secrets.NewSecretWithEntropy(utils.AlphaNumeric("64"), 3.5))
	return utils.Validate(r, tps, nil)
}
