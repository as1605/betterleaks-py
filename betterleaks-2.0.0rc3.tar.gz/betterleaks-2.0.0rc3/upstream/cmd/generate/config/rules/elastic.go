package rules

import (
	"github.com/betterleaks/betterleaks/v2/cmd/generate/config/utils"
	"github.com/betterleaks/betterleaks/v2/cmd/generate/secrets"
	"github.com/betterleaks/betterleaks/v2/config"
)

func ElasticCloudAPIKey() *config.Rule {
	r := config.Rule{
		ID:          "elastic-cloud-api-key",
		Confidence:  "high",
		Description: "Identified an Elastic Cloud Serverless API key, which may expose Elasticsearch and Kibana resources to unauthorized access.",
		Regex:       utils.GenerateUniqueTokenRegex(`essu_[A-Za-z0-9_\-]{60,200}={0,2}`, false),
		Keywords:    []string{"essu_"},
		FilterExpr:  utils.MinEntropy(3.5),
		ValidateExpr: `let r = http.get("https://api.elastic-cloud.com/api/v1/deployments", {
    "Authorization": "ApiKey " + finding["secret"]
  }); r.status == 200 && (r.body contains '"deployments"') ? {
    "result": "valid"
  } : r.status in [401, 403] ? {
    "result": "invalid",
    "reason": "Unauthorized"
  } : validate.unknown(r)`,
	}

	tps := utils.GenerateSampleSecrets("elastic", "essu_"+secrets.NewSecretWithEntropy(`[A-Za-z0-9_\-]{80}`, 3.5))
	fps := []string{
		// Too short
		`elastic_token = essu_abc123`,
		// Wrong prefix
		`elastic_token = ess_abc123def456ghi789jkl012mno345pqr678stu901vwx234yz1234567890`,
	}
	return utils.Validate(r, tps, fps)
}
