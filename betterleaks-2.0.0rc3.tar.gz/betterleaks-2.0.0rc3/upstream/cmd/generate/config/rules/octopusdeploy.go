package rules

import (
	"github.com/betterleaks/betterleaks/v2/cmd/generate/config/utils"
	"github.com/betterleaks/betterleaks/v2/cmd/generate/secrets"
	"github.com/betterleaks/betterleaks/v2/config"
)

func OctopusDeployApiKey() *config.Rule {
	// define rule
	r := config.Rule{
		ID:          "octopus-deploy-api-key",
		Confidence:  "medium",
		Description: "Discovered a potential Octopus Deploy API key, risking application deployments and operational security.",
		Regex:       utils.GenerateUniqueTokenRegex(`API-[A-Z0-9]{26}`, false),
		Keywords:    []string{"api-"},
		FilterExpr:  `entropy(finding["secret"]) <= 3.0`,
	}

	// validate
	tps := []string{
		utils.GenerateSampleSecret("octopus", secrets.NewSecretWithEntropy(`API-[A-Z0-9]{26}`, 3)),
		`set apikey="API-ZNRMR7SL6L3ATMOIK7GKJDKLPY"`, // betterleaks:allow
	}
	fps := []string{
		// Invalid start
		`msgstr "GSSAPI-VIRHEKAPSELOINTIMERKKIJONO."`,
		`https://sonarcloud.io/api/project_badges/measure?project=Garden-Coin_API-CalculadoraDeInvestimentos&metric=alert_status`,
		`https://fog-ringer-f42.notion.site/API-BD80F56CDC1441E6BF6011AB6D852875`,    // Invalid end
		`<iframe src="./archive/gifs/api-c99e353f761d318322c853c03e.gif"> </iframe>`, // Wrong case
	}
	return utils.Validate(r, tps, fps)
}
