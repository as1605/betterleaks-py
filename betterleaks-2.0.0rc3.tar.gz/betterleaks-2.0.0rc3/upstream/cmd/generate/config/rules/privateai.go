package rules

import (
	"github.com/betterleaks/betterleaks/v2/cmd/generate/config/utils"
	"github.com/betterleaks/betterleaks/v2/cmd/generate/secrets"
	"github.com/betterleaks/betterleaks/v2/config"
)

func PrivateAIToken() *config.Rule {
	// https://docs.private-ai.com/reference/latest/operation/metrics_metrics_get/
	r := config.Rule{
		ID:          "privateai-api-token",
		Confidence:  "medium",
		Description: "Identified a PrivateAI Token, posing a risk of unauthorized access to AI services and data manipulation.",
		Regex:       utils.GenerateSemiGenericRegex([]string{"private[_-]?ai"}, `[a-z0-9]{32}`, false),
		Keywords: []string{
			"privateai",
			"private_ai",
			"private-ai",
		},
		FilterExpr: `entropy(finding["secret"]) < 3.5 || tokenRatio(finding["secret"]) >= 2.5`,
	}

	// validate
	tps := []string{
		utils.GenerateSampleSecret("privateai", secrets.NewSecretWithEntropy(utils.AlphaNumeric("32"), 3.5)),
	}
	fps := []string{
		`const privateaiToken = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";`,
	}
	return utils.Validate(r, tps, fps)
}
