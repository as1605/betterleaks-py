package rules

import (
	"github.com/betterleaks/betterleaks/v2/cmd/generate/config/utils"
	"github.com/betterleaks/betterleaks/v2/cmd/generate/secrets"
	"github.com/betterleaks/betterleaks/v2/config"
)

func CohereAPIToken() *config.Rule {
	// define rule
	r := config.Rule{
		ID:          "cohere-api-token",
		Confidence:  "medium",
		Description: "Identified a Cohere Token, posing a risk of unauthorized access to AI services and data manipulation.",
		Regex:       utils.GenerateSemiGenericRegex([]string{"cohere", "CO_API_KEY"}, `[a-zA-Z0-9]{40}`, false),
		Keywords: []string{
			"cohere",
			"CO_API_KEY",
		},
		ValidateExpr: `let r = http.get("https://api.cohere.com/v1/connectors", {
    "Authorization": "Bearer " + finding["secret"]
  }); r.status == 200 && (r.body contains '"connectors"') && (r.body contains '"total_count"') ? {
    "result": "valid"
  } : r.status in [401, 403] ? {
    "result": "invalid",
    "reason": "Unauthorized"
  } : validate.unknown(r)`,
		FilterExpr: `entropy(finding["secret"]) < 4.0 || tokenRatio(finding["secret"]) >= 2.5`,
	}

	// validate
	tps := []string{
		utils.GenerateSampleSecret("cohere", secrets.NewSecretWithEntropy(`[a-zA-Z0-9]{40}`, 4)),
		// https://github.com/cohere-ai/cohere-go/blob/abe8044073ed498ffbb206a602d03c2414b64512/client/client.go#L38C30-L38C40
		`export CO_API_KEY=` + secrets.NewSecretWithEntropy(`[a-zA-Z0-9]{40}`, 4),
	}
	fps := []string{
		`CO_API_KEY=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`,
	}
	return utils.Validate(r, tps, fps)
}
