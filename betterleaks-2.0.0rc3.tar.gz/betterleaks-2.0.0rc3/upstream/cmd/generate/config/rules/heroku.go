package rules

import (
	"github.com/betterleaks/betterleaks/v2/cmd/generate/config/utils"
	"github.com/betterleaks/betterleaks/v2/cmd/generate/secrets"
	"github.com/betterleaks/betterleaks/v2/config"
)

func Heroku() *config.Rule {
	// define rule
	r := config.Rule{
		Description: "Detected a Heroku API Key, potentially compromising cloud application deployments and operational security.",
		ID:          "heroku-api-key",
		Confidence:  "high",
		Regex:       utils.GenerateSemiGenericRegex([]string{"heroku"}, utils.Hex8_4_4_4_12(), true),

		Keywords: []string{"heroku"},
	}

	// validate
	tps := utils.GenerateSampleSecrets("heroku", secrets.NewSecret(utils.Hex8_4_4_4_12()))
	tps = append(tps,
		`const HEROKU_KEY = "12345678-ABCD-ABCD-ABCD-1234567890AB"`, // betterleaks:allow
		`heroku_api_key = "832d2129-a846-4e27-99f4-7004b6ad53ef"`,   // betterleaks:allow
	)
	return utils.Validate(r, tps, nil)
}

func HerokuV2() *config.Rule {
	// define rule
	r := config.Rule{
		Description: "Detected a Heroku API Key, potentially compromising cloud application deployments and operational security.",
		ID:          "heroku-api-key-v2",
		Confidence:  "high",
		Regex:       utils.GenerateUniqueTokenRegex(`(HRKU-AA[0-9a-zA-Z_-]{58})`, false),
		Keywords:    []string{"HRKU-AA"},
		FilterExpr:  `entropy(finding["secret"]) <= 4.0`,
	}

	// validate
	tps := utils.GenerateSampleSecrets("heroku", secrets.NewSecretWithEntropy(`\b(HRKU-AA[0-9a-zA-Z_-]{58})\b`, 4))
	tps = append(tps,
		`const KEY = "HRKU-AAlQ1aVoHDujJ9QsDHdHlHO0hbzhoERRSO45ZQusSYHg_____w4_hLrAym_u""`,
		`API_Key = "HRKU-AAy9Ppr_HD2pPuTyIiTYInO0hbzhoERRSO93ZQusSYHgaD7_WQ07FnF7L9FX"`,
	)
	return utils.Validate(r, tps, nil)
}
