package rules

import (
	"github.com/betterleaks/betterleaks/v2/cmd/generate/config/utils"
	"github.com/betterleaks/betterleaks/v2/cmd/generate/secrets"
	"github.com/betterleaks/betterleaks/v2/config"
)

func Mistral() *config.Rule {
	r := config.Rule{
		ID:          "mistral-api-key",
		Confidence:  "medium",
		Description: "Detected a Mistral AI API Key, which may expose AI language model services to unauthorized access.",
		Regex:       utils.GenerateSemiGenericRegex([]string{"mistral"}, `[A-Z0-9]{32}`, true),
		Keywords:    []string{"mistral"},
		ValidateExpr: `let r = http.get("https://api.mistral.ai/v1/models", {
    "Authorization": "Bearer " + finding["secret"],
    "Accept": "application/json"
  }); r.status == 200 && (r.body contains '"data"') ? {
    "result": "valid"
  } : r.status in [401, 403] ? {
    "result": "invalid",
    "reason": "Unauthorized"
  } : validate.unknown(r)`,
		FilterExpr: `entropy(finding["secret"]) < 3.5 || tokenRatio(finding["secret"]) >= 2.5`,
	}

	tps := utils.GenerateSampleSecrets("mistral", secrets.NewSecretWithEntropy(`[A-Z0-9]{32}`, 3.5))
	fps := []string{
		// Too short
		`mistral_token = 47cFZMzkoEo9DBapfvhrmMst3zfV`,
		// All same chars (low entropy)
		`mistral_token = AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA`,
	}
	return utils.Validate(r, tps, fps)
}
