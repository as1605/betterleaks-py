package rules

import (
	"github.com/betterleaks/betterleaks/v2/cmd/generate/config/utils"
	"github.com/betterleaks/betterleaks/v2/cmd/generate/secrets"
	"github.com/betterleaks/betterleaks/v2/config"
)

func CoinbaseAccessToken() *config.Rule {
	// define rule
	r := config.Rule{
		ID:          "coinbase-access-token",
		Confidence:  "medium",
		Description: "Detected a Coinbase Access Token, posing a risk of unauthorized access to cryptocurrency accounts and financial transactions.",
		Regex: utils.GenerateSemiGenericRegex([]string{"coinbase"},
			utils.AlphaNumericExtendedShort("64"), true),
		Keywords: []string{
			"coinbase",
		},
		FilterExpr: `entropy(finding["secret"]) < 3.5 || tokenRatio(finding["secret"]) >= 2.5`,
	}

	// validate
	tps := utils.GenerateSampleSecrets("coinbase", secrets.NewSecretWithEntropy(utils.AlphaNumericExtendedShort("64"), 3.5))
	return utils.Validate(r, tps, nil)
}
