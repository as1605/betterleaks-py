package rules

import (
	"github.com/betterleaks/betterleaks/v2/cmd/generate/config/utils"
	"github.com/betterleaks/betterleaks/v2/cmd/generate/secrets"
	"github.com/betterleaks/betterleaks/v2/config"
)

func ShopifySharedSecret() *config.Rule {
	// define rule
	r := config.Rule{
		ID:          "shopify-shared-secret",
		Confidence:  "high",
		Description: "Found a Shopify shared secret, posing a risk to application authentication and e-commerce platform security.",
		Regex:       `shpss_[a-fA-F0-9]{32}`,
		Keywords:    []string{"shpss_"},
		FilterExpr:  `entropy(finding["secret"]) <= 2.0`,
	}

	// validate
	tps := utils.GenerateSampleSecrets("shopify", "shpss_"+secrets.NewSecretWithEntropy(utils.Hex("32"), 2))
	return utils.Validate(r, tps, nil)
}

func ShopifyAccessToken() *config.Rule {
	// define rule
	r := config.Rule{
		ID:          "shopify-access-token",
		Confidence:  "high",
		Description: "Uncovered a Shopify access token, which could lead to unauthorized e-commerce platform access and data breaches.",
		Regex:       `shpat_[a-fA-F0-9]{32}`,
		Keywords:    []string{"shpat_"},
		FilterExpr:  `entropy(finding["secret"]) <= 2.0`,
	}

	// validate
	tps := utils.GenerateSampleSecrets("shopify", "shpat_"+secrets.NewSecretWithEntropy(utils.Hex("32"), 2))
	return utils.Validate(r, tps, nil)
}

func ShopifyCustomAccessToken() *config.Rule {
	// define rule
	r := config.Rule{
		ID:          "shopify-custom-access-token",
		Confidence:  "high",
		Description: "Detected a Shopify custom access token, potentially compromising custom app integrations and e-commerce data security.",
		Regex:       `shpca_[a-fA-F0-9]{32}`,
		Keywords:    []string{"shpca_"},
		FilterExpr:  `entropy(finding["secret"]) <= 2.0`,
	}

	// validate
	tps := utils.GenerateSampleSecrets("shopify", "shpca_"+secrets.NewSecretWithEntropy(utils.Hex("32"), 2))
	return utils.Validate(r, tps, nil)
}

func ShopifyPrivateAppAccessToken() *config.Rule {
	// define rule
	r := config.Rule{
		ID:          "shopify-private-app-access-token",
		Confidence:  "high",
		Description: "Identified a Shopify private app access token, risking unauthorized access to private app data and store operations.",
		Regex:       `shppa_[a-fA-F0-9]{32}`,
		Keywords:    []string{"shppa_"},
		FilterExpr:  `entropy(finding["secret"]) <= 2.0`,
	}

	// validate
	tps := utils.GenerateSampleSecrets("shopify", "shppa_"+secrets.NewSecretWithEntropy(utils.Hex("32"), 2))
	return utils.Validate(r, tps, nil)
}
