package rules

import (
	"github.com/betterleaks/betterleaks/v2/cmd/generate/config/utils"
	"github.com/betterleaks/betterleaks/v2/config"
)

func CfxreServerKey() *config.Rule {
	// define rule
	r := config.Rule{
		ID:          "cfxre-server-key",
		Confidence:  "high",
		Description: "Cfx.re FiveM server key.",
		Regex:       `\b(cfxk_[a-zA-Z0-9_-]{20,100})`,
		Keywords:    []string{"cfxk_"},
		FilterExpr:  `entropy(finding["secret"]) <= 3.5`,
	}

	// validate
	tps := []string{
		`sv_licenseKey "cfxk_AbCdEfGhIjKlMnOpQrStUvWx"`,
	}
	fps := []string{
		`cfxk_short`,
	}
	return utils.Validate(r, tps, fps)
}
