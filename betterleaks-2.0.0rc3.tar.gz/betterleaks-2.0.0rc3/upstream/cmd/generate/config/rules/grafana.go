package rules

import (
	"github.com/betterleaks/betterleaks/v2/cmd/generate/config/utils"
	"github.com/betterleaks/betterleaks/v2/cmd/generate/secrets"
	"github.com/betterleaks/betterleaks/v2/config"
)

func GrafanaApiKey() *config.Rule {
	// define rule
	r := config.Rule{
		ID:          "grafana-api-key",
		Confidence:  "high",
		Description: "Identified a Grafana API key, which could compromise monitoring dashboards and sensitive data analytics.",
		Regex:       utils.GenerateUniqueTokenRegex(`eyJrIjoi[A-Za-z0-9+/]{40,380}={0,2}`, false),
		Keywords:    []string{"eyJrIjoi"},
		FilterExpr:  utils.MinEntropy(3.0),
	}

	// validate
	tps := utils.GenerateSampleSecrets("grafana-api-key", "eyJrIjoi"+secrets.NewSecretWithEntropy(`[A-Za-z0-9+/]{70}`, 3.5))
	tps = append(tps, `Authorization: Bearer eyJrIjoiWHZiSWd5NzdCYUZnNUtibE8obUpESmE2bzJYNDRIc1UiLCJuIjoibXlrZXkiLCJpZCI6MX0=`)
	return utils.Validate(r, tps, nil)
}

func GrafanaCloudApiToken() *config.Rule {
	// define rule
	r := config.Rule{
		ID:           "grafana-cloud-api-token",
		Confidence:   "high",
		Description:  "Found a Grafana cloud API token, risking unauthorized access to cloud-based monitoring services and data exposure.",
		Regex:        utils.GenerateUniqueTokenRegex(`glc_[A-Za-z0-9+/]{40,150}={0,2}`, false),
		Keywords:     []string{"glc_"},
		ValidateExpr: utils.BearerGetValidationExpr("https://grafana.com/api/stack-regions", "true"),
		FilterExpr:   utils.MinEntropy(3.0),
	}

	// validate
	tps := utils.GenerateSampleSecrets("grafana-cloud-api-token", "glc_"+secrets.NewSecretWithEntropy(`[A-Za-z0-9+/]{40}`, 3.5))
	tps = append(tps,
		utils.GenerateSampleSecret("grafana-cloud-api-token",
			"glc_"+
				secrets.NewSecretWithEntropy(`[A-Za-z0-9+/]{40}`, 3.5)),
		`loki_key: glc_eyJvIjoiNzQ0NTg3IiwibiI7InN0YWlrLTQ3NTgzMC1obC13cml0ZS1oYW5kc29uJG9raSIsImsiOiI4M2w3cmdYUlBoMTUyMW1lMU023nl5UDUiLCJtIjp7IOIiOiJ1cyJ9fQ==`,
		// TODO:
		//`  loki:
		//endpoint: https://322137:glc_eyJvIjoiNzQ0NTg3IiwibiI7InN0YWlrLTQ3NTgzMC1obC13cml0ZS1oYW5kc29uJG9raSIsImsiOiI4M2w3cmdYUlBoMTUyMW1lMU023nl5UDUiLCJtIjp7IOIiOiJ1cyJ9fQ==@logs-prod4.grafana.net/loki/api/v1/push`,
	)
	fps := []string{
		// Low entropy.
		`glc_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`,
		`   API_KEY="glc_111111111111111111111111111111111111111111="`,
		// Invalid.
		`static void GLC_CreateLightmapTextureArray(void);
static void GLC_CreateLightmapTexturesIndividual(void);

void GLC_UploadLightmap(int textureUnit, int lightmapnum);`,
		`// Alias models
void GLC_StateBeginUnderwaterAliasModelCaustics(texture_ref base_texture, texture_ref caustics_texture)
{`,
	}
	return utils.Validate(r, tps, fps)
}

func GrafanaServiceAccountToken() *config.Rule {
	// define rule
	r := config.Rule{
		ID:          "grafana-service-account-token",
		Confidence:  "high",
		Description: "Discovered a Grafana service account token, posing a risk of compromised monitoring services and data integrity.",
		Regex:       utils.GenerateUniqueTokenRegex(`glsa_[A-Za-z0-9]{32}_[A-Fa-f0-9]{8}`, false),
		Keywords:    []string{"glsa_"},
		FilterExpr:  utils.MinEntropy(3.0),
	}

	// validate
	tps := utils.GenerateSampleSecrets("grafana-service-account-token", "glsa_"+secrets.NewSecretWithEntropy(utils.AlphaNumeric("32"), 3.5)+"_"+secrets.NewSecret(utils.Hex("8")))
	tps = append(tps,
		`'Authorization': 'Bearer glsa_pITqMOBIfNH2KL4PkXJqmTyQl0D9QGxF_486f63e1'`,
	)
	fps := []string{
		"glsa_XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_AAAAAAAA",
	}
	return utils.Validate(r, tps, fps)
}
