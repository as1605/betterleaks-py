package rules

import (
	"github.com/betterleaks/betterleaks/v2/cmd/generate/config/utils"
	"github.com/betterleaks/betterleaks/v2/cmd/generate/secrets"
	"github.com/betterleaks/betterleaks/v2/config"
)

func DeepSeek() *config.Rule {
	r := config.Rule{
		ID:          "deepseek-api-key",
		Confidence:  "high",
		Description: "Detected a DeepSeek API Key, which may expose AI model access and associated usage to unauthorized parties.",
		Regex:       utils.GenerateSemiGenericRegex([]string{"deepseek"}, `sk-[a-f0-9]{32}`, true),
		Keywords:    []string{"deepseek"},
		ValidateExpr: `let r = http.get("https://api.deepseek.com/models", {
    "Authorization": "Bearer " + finding["secret"],
    "Accept": "application/json"
  }); r.status == 200 && (r.body contains '"data"') ? {
    "result": "valid"
  } : r.status in [401, 403] ? {
    "result": "invalid",
    "reason": "Unauthorized"
  } : validate.unknown(r)`,
		FilterExpr: `entropy(finding["secret"]) <= 3.5`,
	}

	tps := utils.GenerateSampleSecrets("deepseek", "sk-"+secrets.NewSecretWithEntropy(utils.Hex("32"), 3.5))
	fps := []string{
		// Too short
		`deepseek_key = sk-ba588036180d4d1d9cebbf`,
		// All zeros (low entropy)
		`deepseek_key = sk-00000000000000000000000000000000`,
	}
	return utils.Validate(r, tps, fps)
}
