package rules

import (
	"github.com/betterleaks/betterleaks/v2/cmd/generate/config/utils"
	"github.com/betterleaks/betterleaks/v2/cmd/generate/secrets"
	"github.com/betterleaks/betterleaks/v2/config"
)

func LarkAppID() *config.Rule {
	// define rule
	r := config.Rule{
		ID:          "lark-app-id",
		Confidence:  "high",
		Description: "Lark application ID, used as a component of the Lark application-secret rule.",
		Regex:       `\b(cli_[A-Za-z0-9]{16})`,
		Keywords:    []string{"cli_"},
		SkipReport:  true,
		FilterExpr:  `entropy(finding["secret"]) < 3.0 || tokenRatio(finding["secret"]) >= 2.5`,
	}

	// validate
	tps := []string{
		`LARK_APP_ID=cli_AbCdEfGhIjKlMnOp`,
	}
	fps := []string{
		`LARK_APP_ID=cli_short`,
	}
	return utils.Validate(r, tps, fps)
}

func LarkAppSecret() *config.Rule {
	// define rule
	r := config.Rule{
		ID:          "lark-app-secret",
		Confidence:  "high",
		Description: "Lark application secret.",
		Regex: utils.GenerateSemiGenericRegex(
			[]string{"lark", "larksuite"},
			`[A-Za-z0-9]{32}`,
			true,
		),
		Keywords: []string{"lark"},
		Components: []config.Component{
			{RuleID: "lark-app-id"},
		},
		ValidateExpr: `let r = http.post("https://open.larksuite.com/open-apis/auth/v3/tenant_access_token/internal", {
    "Content-Type": "application/json",
    "Accept": "application/json"
  }, "{\"app_id\":" + toJSON((components["lark-app-id"]?.secret ?? "")) + ",\"app_secret\":" + toJSON(finding["secret"]) + "}");
let code = r.json?.code ?? -1;
r.status == 200 && code == 0 ? {
    "result": "valid"
  } : r.status == 200 && code in [10003, 10005, 10014, 10015] ? {
    "result": "invalid",
    "reason": (r.json?.msg ?? "Invalid application credentials")
  } : validate.unknown(r)`,
		FilterExpr: `entropy(finding["secret"]) < 3.5 || tokenRatio(finding["secret"]) >= 2.5`,
	}

	// validate
	tps := []string{
		"LARK_APP_SECRET=" + secrets.NewSecretWithEntropy(utils.AlphaNumeric("32"), 3.5),
	}
	fps := []string{
		`LARK_APP_SECRET=short`,
		`OTHER_APP_SECRET=AbCdEfGhIjKlMnOpQrStUvWxYz123456`,
	}
	return utils.Validate(r, tps, fps)
}
