package rules

import (
	"github.com/betterleaks/betterleaks/v2/cmd/generate/config/utils"
	"github.com/betterleaks/betterleaks/v2/config"
)

func EtsyAccessToken() *config.Rule {
	r := config.Rule{
		ID:          "etsy-open-api-key",
		Confidence:  "high",
		Description: "Found an Etsy Open API key, potentially compromising Etsy app access and shop integrations.",
		Regex:       utils.GenerateSemiGenericRegex([]string{"etsy", "x-api-key"}, utils.AlphaNumeric("24")+`:`+utils.AlphaNumeric("10,64"), true),
		Keywords: []string{
			"etsy",
			"x-api-key",
		},
		ValidateExpr: `let k = split(finding["secret"], ":")[0]; (let r = http.get("https://api.etsy.com/v3/application/openapi-ping", {
      "x-api-key": k,
      "Accept": "application/json"
    }); r.status == 200 ? {
      "result": "valid"
    } : r.status in [401, 403] ? {
      "result": "invalid",
      "reason": "Unauthorized"
    } : validate.unknown(r))`,
		FilterExpr: utils.MinEntropy(3.0),
	}

	tps := []string{
		`x-api-key: 1aa2bb33c44d55eeeeee6fff:a1b2c3d4e5`,
		`ETSY_API_KEY=1aa2bb33c44d55eeeeee6fff:a1b2c3d4e5`,
	}
	fps := []string{
		`ETSY_API_KEY=your_api_key:your_key_here`,
	}
	return utils.Validate(r, tps, fps)
}
