package rules

import (
	"github.com/betterleaks/betterleaks/v2/cmd/generate/config/utils"
	"github.com/betterleaks/betterleaks/v2/cmd/generate/secrets"
	"github.com/betterleaks/betterleaks/v2/config"
)

func Doppler() *config.Rule {
	// define rule
	r := config.Rule{
		ID:          "doppler-api-token",
		Confidence:  "high",
		Description: "Discovered a Doppler API token, posing a risk to environment and secrets management security.",
		Regex:       `dp\.pt\.(?i)[a-z0-9]{43}`,
		Keywords:    []string{`dp.pt.`},
		FilterExpr:  `entropy(finding["secret"]) <= 2.0`,
	}

	// validate
	tps := utils.GenerateSampleSecrets("doppler", "dp.pt."+secrets.NewSecretWithEntropy(utils.AlphaNumeric("43"), 2))
	return utils.Validate(r, tps, nil)
}

// TODO add additional doppler formats:
// https://docs.doppler.com/reference/auth-token-formats
