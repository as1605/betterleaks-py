package rules

import (
	"github.com/betterleaks/betterleaks/v2/cmd/generate/config/utils"
	"github.com/betterleaks/betterleaks/v2/cmd/generate/secrets"
	"github.com/betterleaks/betterleaks/v2/config"
)

func PyPiUploadToken() *config.Rule {
	// define rule
	r := config.Rule{
		Description: "Discovered a PyPI upload token, potentially compromising Python package distribution and repository integrity.",
		ID:          "pypi-upload-token",
		Confidence:  "high",
		Regex:       `pypi-AgEIcHlwaS5vcmc[\w-]{50,1000}`,
		Keywords: []string{
			"pypi-AgEIcHlwaS5vcmc",
		},
		FilterExpr: `entropy(finding["secret"]) <= 3.0`,
	}

	// validate
	tps := utils.GenerateSampleSecrets("pypi", "pypi-AgEIcHlwaS5vcmc"+secrets.NewSecretWithEntropy(utils.Hex("32"), 3)+secrets.NewSecretWithEntropy(utils.Hex("32"), 3))
	return utils.Validate(r, tps, nil)
}
