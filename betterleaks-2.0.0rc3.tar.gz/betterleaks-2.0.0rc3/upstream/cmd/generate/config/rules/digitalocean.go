package rules

import (
	"github.com/betterleaks/betterleaks/v2/cmd/generate/config/utils"
	"github.com/betterleaks/betterleaks/v2/cmd/generate/secrets"
	"github.com/betterleaks/betterleaks/v2/config"
)

func DigitalOceanPAT() *config.Rule {
	r := config.Rule{
		ID:          "digitalocean-pat",
		Confidence:  "high",
		Description: "Discovered a DigitalOcean Personal Access Token, posing a threat to cloud infrastructure security and data privacy.",
		Regex:       utils.GenerateUniqueTokenRegex(`dop_v1_[a-f0-9]{64}`, false),
		Keywords:    []string{"dop_v1_"},
		FilterExpr:  `entropy(finding["secret"]) <= 3.0`,
	}

	tps := utils.GenerateSampleSecrets("do", "dop_v1_"+secrets.NewSecretWithEntropy(utils.Hex("64"), 3))
	return utils.Validate(r, tps, nil)
}

func DigitalOceanOAuthToken() *config.Rule {
	r := config.Rule{
		ID:          "digitalocean-access-token",
		Confidence:  "high",
		Description: "Found a DigitalOcean OAuth Access Token, risking unauthorized cloud resource access and data compromise.",
		Regex:       utils.GenerateUniqueTokenRegex(`doo_v1_[a-f0-9]{64}`, false),
		Keywords:    []string{"doo_v1_"},
		FilterExpr:  `entropy(finding["secret"]) <= 3.0`,
	}

	tps := utils.GenerateSampleSecrets("do", "doo_v1_"+secrets.NewSecretWithEntropy(utils.Hex("64"), 3))
	return utils.Validate(r, tps, nil)
}

func DigitalOceanRefreshToken() *config.Rule {
	r := config.Rule{
		Description: "Uncovered a DigitalOcean OAuth Refresh Token, which could allow prolonged unauthorized access and resource manipulation.",
		ID:          "digitalocean-refresh-token",
		Confidence:  "high",

		Regex:    utils.GenerateUniqueTokenRegex(`dor_v1_[a-f0-9]{64}`, true),
		Keywords: []string{"dor_v1_"},
	}

	tps := utils.GenerateSampleSecrets("do", "dor_v1_"+secrets.NewSecret(utils.Hex("64")))
	return utils.Validate(r, tps, nil)
}
