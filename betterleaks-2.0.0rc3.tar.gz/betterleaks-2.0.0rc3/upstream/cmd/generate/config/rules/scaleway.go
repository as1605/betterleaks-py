package rules

import (
	"github.com/betterleaks/betterleaks/v2/cmd/generate/config/utils"
	"github.com/betterleaks/betterleaks/v2/cmd/generate/secrets"
	"github.com/betterleaks/betterleaks/v2/config"
)

func ScalewaySecretKey() *config.Rule {
	r := config.Rule{
		ID:          "scaleway-secret-key",
		Confidence:  "high",
		Description: "Identified a standalone Scaleway Secret Key. This can be used to authenticate API requests.",
		Regex: utils.GenerateSemiGenericRegex(
			[]string{`(?:scaleway|scw).{0,20}?(?:secret|token)`},
			utils.Hex8_4_4_4_12(),
			true,
		),
		FilterExpr: utils.MinEntropy(3),
		Keywords:   []string{"scaleway", "scw"},
		ValidateExpr: `let r = http.get("https://api.scaleway.com/instance/v1/zones/fr-par-1/servers", {
    "X-Auth-Token": secret,
    "Accept": "application/json"
  }); r.status in [200, 403] ? {
    "result": "valid",
    "metadata": {"permission_status": r.status == 200 ? "Active" : "Restricted but still valid (403)"}
  } : r.status == 401 ? {
    "result": "invalid",
    "reason": "Unauthorized"
  } : validate.unknown(r)`,
	}

	secret := secrets.NewSecretWithEntropy(utils.Hex8_4_4_4_12(), 3)
	tps := []string{
		`scaleway_secret = "` + secret + `"`,
		`scw_token: "` + secret + `"`,
		`SCW_SECRET := "` + secret + `"`,
	}
	fps := []string{
		`scaleway_secret = "not-a-uuid"`,
		`scw_token = "12345678-1234-1234-1234-12345678901"`,
	}

	return utils.Validate(r, tps, fps)
}
